"""
SOURCE:
    Mind of Douglas Adams
DESCRIPTION:
    Graph a scatter plot in 2d or 3d -> depending on the dataset dimensions:
    Takes a Type_NumpyTwoDimensionalDataset -> 
    If it has 3 columns -> 3d
    If it has 2 columns -> 2d
    Then it creates the points
    Colors are by defualt black, and labels can be added outside the method
ARGS:
    CheckArguments
        Type:
            python boolean
        Description:
            if true, checks the arguments with conditions written in the function
            if false, ignores those conditions
    PrintExtra
        Type:
            python integer
        Description:
            if greater than 0, prints addional information about the function
            if 0, function is expected to print nothing to console
            Additional Notes:
                The greater the number, the more output the function will print
                Most functions only use 0 or 1, but some can print more depending on the number
    NumpyTwoDimensionalDataset
        Type:
            <type 'NoneType'>
        Description:
RETURNS:
    Result
        Type:
        Description:
"""

import numpy
import matplotlib
import matplotlib.pyplot
import matplotlib.pyplot as plt
from matplotlib import cm
from mpl_toolkits.mplot3d import Axes3D
#------------------------------------------------------------------------------
import Type_NumpyTwoDimensionalDataset
def Main(
    NumpyTwoDimensionalDataset= None,
    NumpyTwoDimensionalDatasets = None,
    DatasetLabels = None,
    ExistingFigure = None,
    Xlabel = "X", 
    Ylabel = "Y", 
    Zlabel = "Z",
    PlotTitle = None,
    SaveFigureFilePath = None,
    markersize = 3,
    c = [.5,.5,.5],
    colors = None,
    ConnectPoints = False,

    LogDomain = False, 
    LogRange = False,


    CheckArguments = True,
    PrintExtra = False,
    ):

    Result = None



    #Create the none args
    if (NumpyTwoDimensionalDatasets is not None):
        FirstDataset = NumpyTwoDimensionalDatasets[0]
        #print 'FirstDataset', FirstDataset
        for Dataset in NumpyTwoDimensionalDatasets:
            #print 'Dataset', Dataset
            if (Type_NumpyTwoDimensionalDataset.Main(Dataset) != True ):
                raise Exception('"(Type_NumpyTwoDimensionalDataset.Main(NumpyTwoDimensionalDataset) != True)\n"')
            if Dataset.shape[1] != FirstDataset.shape[1]:
                print('Dataset.shape', Dataset.shape)
                print('FirstDataset.shape', FirstDataset.shape)
                raise Exception('All Datasets must have same number of columns')
    else:
        if NumpyTwoDimensionalDataset is not None:
            NumpyTwoDimensionalDatasets = [NumpyTwoDimensionalDataset]
            colors = [c]
        else:
            raise Exception('Arg fail, needs at least one of [NumpyTwoDimensionalDataset, NumpyTwoDimensionalDatasets]')
    if colors is None:
        colors =   numpy.random.rand(len(NumpyTwoDimensionalDatasets), 3 )  


    DatasetCount = len(NumpyTwoDimensionalDatasets)
    if (DatasetLabels is None):
        DatasetLabels = [None]*DatasetCount


    #Check args:
    if (CheckArguments):
        ArgumentErrorMessage = ""

        if (len(ArgumentErrorMessage) > 0 ):
            if(PrintExtra):
                print("ArgumentErrorMessage:\n", ArgumentErrorMessage)
            raise Exception(ArgumentErrorMessage)
   



    #size the graphs
    #   Default to common monitor size:  
    #   1920pixels by 1080 pixels
    Inch_in_Pixels = 80.0
    MonitorSize = (1920.0/Inch_in_Pixels,1080.0/Inch_in_Pixels)

    #Create the figure:
    fig = None
    if ExistingFigure is None:
        fig = matplotlib.pyplot.figure(figsize=MonitorSize) #figsize=MonitorSize
    else:
        fig = ExistingFigure


    #Add the subplot based one weather or not the figure is 2 or three dimensional
    RowCountFirst = NumpyTwoDimensionalDatasets[0].shape[0]
    ColCountFirst = NumpyTwoDimensionalDatasets[0].shape[1]
    if (RowCountFirst == 2):
        subplot = fig.add_subplot(111)
    elif (ColCountFirst == 3):
        subplot = fig.add_subplot(111, projection='3d')

    #Loop through each dataset and plot each set of points in a different color
    for NumpyTwoDimensionalDataset, DatasetLabel, color in zip(NumpyTwoDimensionalDatasets, DatasetLabels, colors):
        #print 'color', color
        RowCount = NumpyTwoDimensionalDataset.shape[0]
        ColCount = NumpyTwoDimensionalDataset.shape[1]
        if not (ColCount in [2,3]):
            raise Exception('Col count not manageable')

        NumpyTwoDimensionalDatasetTranspose = NumpyTwoDimensionalDataset.T
        Xvals = NumpyTwoDimensionalDatasetTranspose[0]
        Yvals = NumpyTwoDimensionalDatasetTranspose[1]




        if (ColCount == 2):

            if (LogDomain):
                pass
            if (LogRange):
                YVals = numpy.log(YVals)


            matplotlib.pyplot.scatter(
                Xvals, 
                Yvals,
                c=color, 
                label = DatasetLabel,
                #markersize=markersize, 
                alpha=0.5)

            if ConnectPoints:
                matplotlib.pyplot.plot(
                    Xvals, 
                    Yvals,
                    c=color, 
                    label = DatasetLabel,
                    #markersize=markersize, 
                    alpha=0.5)
            plt.grid(True)
            try:
                font = {
                    'weight' : 'bold',
                    'size'   : 22 
                    }

                matplotlib.rc('font', **font)
            except:
                pass


        elif (ColCount == 3):
            Zvals = NumpyTwoDimensionalDatasetTranspose[2]
            
            matplotlib.pyplot.plot(
                Xvals, 
                Yvals,
                Zvals,  
                c=color, 
                label = DatasetLabel,
                #markersize=markersize, 
                 marker='o',
                linestyle = 'None',
                alpha=0.5)

            """
            subplot = fig.add_subplot(111, projection='3d')

            subplot.set_xlabel(Xlabel)
            subplot.set_ylabel(Ylabel)
            subplot.set_zlabel(Zlabel)     

            subplot.plot(
                Xvals, 
                Yvals,
                Zvals,  
                c=color, 
                label = DatasetLabel,
                #markersize=markersize, 
                 marker='o',
                linestyle = 'None',
                alpha=0.5)
            """
            #ax = fig.add_subplot(111, projection='3d')
            #ax.scatter(Xvals, Yvals, Zvals, c='r', marker='o')

        else:
            raise Exception('ColCount not logical')

    #Add lables:

    if (Xlabel is not None):
        plt.xlabel(Xlabel)
    if (Ylabel is not None):
        plt.ylabel(Ylabel)
    #if (Zlabel is not None):


    if (PlotTitle is not None):
        plt.title(PlotTitle)
    if (not None in DatasetLabels):
        matplotlib.pyplot.legend(loc = 'best')
    if (SaveFigureFilePath is not None):
        plt.savefig( SaveFigureFilePath )
        plt.close()
    return Result 












